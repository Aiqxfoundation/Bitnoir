import { Router, type IRouter } from "express";
import accountsRouter from "./accounts";
import adminRouter from "./admin";
import bitsRouter from "./bits";
import walletsRouter from "./wallets";

const router: IRouter = Router();

router.use(accountsRouter);
router.use(bitsRouter);
router.use(walletsRouter);
router.use(adminRouter);

export default router;
