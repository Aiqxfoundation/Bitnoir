import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, Show, useAuth, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import {
  useCreateMyProfile, useGetAdminAuditLog, useGetAdminBitsLedger, useGetAdminUsers, useGetLeaderboard,
  useGetMyBitsLedger, useGetMyProfile, useGetMyWallets, useGetWalletNonce,
  useTransferBits, useVerifyWallet,
  getGetMyBitsLedgerQueryKey,
  getGetMyProfileQueryKey, getGetMyWalletsQueryKey,
} from '@workspace/api-client-react';
import type { AdminLedgerEntry, AdminUser, AuditEvent, BitsLedgerEntry, LeaderboardEntry, UserProfile, WalletAssociation } from '@workspace/api-client-react';
import { ArrowDownLeft, ArrowLeftRight, ArrowUpRight, BookOpen, Check, ChevronRight, Copy, ExternalLink, LayoutDashboard, LogOut, Menu, Shield, Sparkles, Users, Wallet, X } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
function stripBase(path: string) { return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path; }
if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
const clerkAppearance = {
  theme: shadcn, cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
  variables: { colorPrimary: '#d9b85b', colorForeground: '#e8e5dc', colorMutedForeground: '#9699a2', colorDanger: '#e18079', colorBackground: '#15171d', colorInput: '#101218', colorInputForeground: '#e8e5dc', colorNeutral: '#393c45', fontFamily: 'DM Sans, sans-serif', borderRadius: '8px' },
  elements: {
    rootBox: 'w-full flex justify-center', cardBox: 'bg-[#15171d] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#30333b]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none', footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#efede6] font-semibold', headerSubtitle: 'text-[#a0a2aa]', socialButtonsBlockButtonText: 'text-[#dddce0]',
    formFieldLabel: 'text-[#c2c3c8]', footerActionLink: 'text-[#e5c464]', footerActionText: 'text-[#92949d]', dividerText: 'text-[#858892]',
    identityPreviewEditButton: 'text-[#e5c464]', formFieldSuccessText: 'text-[#9bc6a8]', alertText: 'text-[#f1c4bf]',
    logoBox: 'rounded-lg', logoImage: 'object-contain', socialButtonsBlockButton: 'border border-[#343741] bg-[#111319] hover:bg-[#1c1e25]',
    formButtonPrimary: 'bg-[#e5c464] text-[#17150f] hover:bg-[#f0d37e]', formFieldInput: 'bg-[#101218] border-[#363943] text-[#efede6]',
    footerAction: 'text-[#92949d]', dividerLine: 'bg-[#343741]', alert: 'bg-[#281a19] border-[#65413d]',
    otpCodeFieldInput: 'bg-[#101218] border-[#363943] text-[#efede6]', formFieldRow: 'text-[#c2c3c8]', main: 'text-[#e8e5dc]',
  },
};

function Brand({ compact = false }: { compact?: boolean }) {
  return <Link href="/" className="brand" data-testid="link-brand"><img src={`${basePath}/bitnoir-coin.png`} alt="" /><span>{compact ? 'BITNOIR' : 'BITNOIR'}</span></Link>;
}
function PublicShell({ children }: { children: ReactNode }) {
  return <div className="shell"><header className="topbar"><div className="wrap" style={{ display: 'flex', alignItems: 'center', width: 'min(1160px, calc(100% - 56px))' }}>
    <Brand /><nav className="nav-links" aria-label="Main navigation"><Link href="/docs">Documentation</Link><Link href="/leaderboard">Leaderboard</Link></nav>
    <div className="nav-actions"><Link href="/sign-in" className="btn btn-quiet" data-testid="link-sign-in">Sign in</Link><Link href="/sign-up" className="btn btn-primary" data-testid="link-create-account">Create account</Link></div>
  </div></header>{children}<Footer /></div>;
}
function Footer() {
  return <footer className="footer"><div className="wrap footer-inner"><span>© Bitnoir · Clear-eyed crypto intelligence</span><div className="footer-links"><Link href="/docs">Project notes</Link><Link href="/leaderboard">Bits leaderboard</Link></div></div></footer>;
}
function Home() {
  return <PublicShell><main>
    <section className="hero"><div className="wrap hero-grid"><div>
      <div className="eyebrow">A more considered crypto ecosystem</div>
      <h1>Clarity for a market that rarely <em>offers it.</em></h1>
      <p className="hero-copy">Bitnoir is being built around practical crypto intelligence, transparent participation, and a community that values substance over noise.</p>
      <div className="hero-actions"><Link href="/sign-up" className="btn btn-primary" data-testid="link-get-started">Create your account <ChevronRight size={15} /></Link><Link href="/docs" className="btn" data-testid="link-explore-project">Explore the project</Link></div>
      <div className="hero-note"><i /> Early-stage platform. Feature availability is stated plainly.</div>
    </div><div className="coinstage"><img src={`${basePath}/bitnoir-coin.png`} alt="Bitnoir coin emblem" /><div className="coin-caption">A mark of the ecosystem</div></div></div></section>
    <section className="section"><div className="wrap principles"><div><div className="eyebrow">What Bitnoir stands for</div><h2 style={{ font: '500 clamp(30px,4vw,42px)/1.14 var(--app-font-serif)', letterSpacing: '-.04em', margin: '14px 0 24px' }}>Useful by design.<br />Honest by default.</h2><p style={{ color: '#898b94', fontSize: 13, lineHeight: 1.75, maxWidth: 410 }}>A crypto platform should tell you what works today, what is still being built, and what your participation actually means. That is the standard we are setting for Bitnoir.</p><Link href="/docs" className="text-link" style={{ color: '#d9b85b', fontSize: 12, display: 'inline-flex', gap: 7, alignItems: 'center', marginTop: 15 }}>Read our project notes <ChevronRight size={14} /></Link></div>
      <div className="principle-list"><Principle n="01" title="Practical intelligence" text="AI-assisted research is a future direction, not a live service. We will label it clearly when it is ready." /><Principle n="02" title="Transparent participation" text="Bits are internal platform points with no promised monetary value. Balances and transfers are shown plainly." /><Principle n="03" title="Trust before features" text="No deposits, withdrawals, swaps, or token payments are available. There is no hidden trading flow." /></div></div></section>
    <section className="section"><div className="wrap"><div className="section-head"><div><div className="eyebrow">Availability, today</div><h2>Current state, in plain terms</h2></div><p>Bitnoir is early. We distinguish the live account features from future plans, without implying a launch date.</p></div><div className="principles"><StatusPanel /><div className="panel panel-pad coming"><div className="coming-mark">On the roadmap</div><h3 style={{ font: '500 23px var(--app-font-serif)', margin: '12px 0 8px' }}>A broader crypto toolkit</h3><p style={{ color: '#92949d', fontSize: 12, lineHeight: 1.75, maxWidth: 390 }}>AI intelligence, farming, token payments, deposits, withdrawals, and swaps are not available. BTNR is planned and has not been deployed.</p><Link href="/docs" className="btn" style={{ marginTop: 14 }} data-testid="link-read-roadmap">Read proposed tokenomics <ChevronRight size={14} /></Link></div></div></div></section>
    <section className="section"><div className="wrap" style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 28, alignItems: 'center' }}><div><div className="eyebrow">Start with an account</div><h2 style={{ font: '500 clamp(28px,4vw,39px) var(--app-font-serif)', letterSpacing: '-.04em', margin: '12px 0 9px' }}>A clear place to begin.</h2><p style={{ color: '#8e9099', fontSize: 13 }}>Create your profile, see your Bits ledger, and explore the ecosystem at your own pace.</p></div><Link href="/sign-up" className="btn btn-primary" data-testid="link-create-profile">Create account <ChevronRight size={15} /></Link></div></section>
  </main></PublicShell>;
}
function Principle({ n, title, text }: { n: string; title: string; text: string }) { return <div className="principle"><div className="num">{n}</div><div><h3>{title}</h3><p>{text}</p></div></div>; }
function StatusPanel() {
  const rows = [['BTNR token', 'Planned · not deployed'], ['AI intelligence', 'Unavailable'], ['Farming & token payments', 'Unavailable'], ['Deposits, withdrawals & swaps', 'Unavailable'], ['Bits points', 'Internal points only']];
  return <div className="status-panel"><div className="eyebrow">Product status</div><h3>What is live — and what is not.</h3><p>Availability is presented as it stands, not as a promise of future delivery.</p>{rows.map(([a, b]) => <div className="status-row" key={a}><span>{a}</span><span className="status">{b}</span></div>)}</div>;
}
function Docs() {
  return <PublicShell><main className="section"><div className="wrap docs-layout"><aside className="docs-side"><b style={{ color: '#d9b85b', font: '10px var(--app-font-mono)', letterSpacing: '.15em' }}>PROJECT DOCUMENTATION</b><a href="#overview">Overview</a><a href="#principles">Operating principles</a><a href="#bits">Bits points</a><a href="#token">Proposed tokenomics</a><a href="#availability">Availability</a><a href="#admin">Launch governance</a></aside><article className="docs-content"><div className="eyebrow">Project notes · first release</div><h1 className="page-title" style={{ fontSize: 43, marginTop: 16 }}>A transparent foundation.</h1><p className="page-subtitle">This document describes the product as it exists today and separates current features from proposals. It is informational, not a financial offer.</p>
      <h2 id="overview">01 / Overview</h2><p>Bitnoir is an early-stage crypto ecosystem focused on practical intelligence and transparent platform participation. The first release centers on accounts, internal Bits accounting, referrals, verified wallet associations, and a public leaderboard.</p>
      <h2 id="principles">02 / Operating principles</h2><ul><li>Make current capability and product limitations easy to understand.</li><li>Keep internal participation points separate from any future token.</li><li>Do not present planned services as active or guaranteed.</li><li>Keep account and administrative actions auditable.</li></ul>
      <h2 id="bits">03 / Bits points</h2><p>Bits are internal platform points used for participation features. They are not a cryptocurrency, are not a claim on assets, and have no promised monetary value. Bits cannot currently be deposited, withdrawn, swapped, or redeemed for tokens or cash.</p>
      <h2 id="token">04 / Proposed tokenomics</h2><p>BTNR is planned and has not been deployed. The following is a discussion framework only; allocations, supply, utility, dates, and launch mechanics are not finalized.</p><div className="notice"><b>Proposal, not issuance.</b> No BTNR token contract is currently deployed, and no allocation below should be interpreted as final or guaranteed.</div><div className="proposed-grid"><Proposal title="Utility" text="Potential ecosystem participation utility is under consideration." /><Proposal title="Supply" text="No confirmed supply or distribution schedule published." /><Proposal title="Allocation" text="Any future allocation would require clear public documentation." /><Proposal title="Launch" text="No token launch date or market availability is announced." /></div>
      <h2 id="availability">05 / Services and availability</h2><p>AI-powered intelligence, farming, token payments, deposits, withdrawals, and swaps are unavailable in this release. No controls for those services are active. Their future development is not a promise of delivery.</p>
      <h2 id="admin">06 / Launch governance</h2><p>The first account that registers is automatically assigned Super Admin by the backend. This is a material launch risk: before public registration opens, the team should confirm the intended first account, restrict access during setup, and review the resulting role. Administration is enforced by backend authorization.</p><p>Bitnoir may update these project notes as the product evolves. Changes to token plans will be clearly identified as proposals until formally confirmed.</p>
    </article></div></main></PublicShell>;
}
function Proposal({ title, text }: { title: string; text: string }) { return <div className="proposal"><b>{title}</b><span>{text}</span></div>; }
function Leaderboard() {
  const q = useGetLeaderboard({ limit: 50, offset: 0 });
  const rows = q.data as LeaderboardEntry[] | undefined;
  return <PublicShell><main className="section"><div className="wrap"><div className="content-heading"><div className="eyebrow">Community standings</div><h1 className="page-title" style={{ marginTop: 13 }}>Bits leaderboard</h1><p className="page-subtitle">A view of internal Bits participation points. Bits have no promised monetary value.</p></div><div className="panel panel-pad"><div className="panel-heading"><h2>Rankings</h2><span className="meta">RANK · USERNAME · BITS</span></div>{q.isLoading ? <SkeletonRows /> : q.isError ? <QueryError retry={() => q.refetch()} /> : !rows?.length ? <Empty title="No rankings yet" text="Leaderboard entries will appear when account participation is recorded." /> : <div style={{ overflowX: 'auto' }}><table className="table"><thead><tr><th>Rank</th><th>Username</th><th style={{ textAlign: 'right' }}>Bits</th></tr></thead><tbody>{rows.map((r) => <tr key={`${r.rank}-${r.username}`} data-testid={`row-leaderboard-${r.rank}`}><td className="rank mono">#{r.rank}</td><td>{r.username}</td><td className="mono" style={{ textAlign: 'right' }}>{formatBits(r.bitsBalance)}</td></tr>)}</tbody></table></div>}</div></div></main></PublicShell>;
}
function SkeletonRows() { return <div style={{ display: 'grid', gap: 14, padding: 20 }}>{[1, 2, 3, 4].map(x => <div className="loader" key={x} style={{ width: `${95 - x * 9}%` }} />)}</div>; }
function QueryError({ retry }: { retry: () => void }) { return <div className="empty"><strong>Could not load this information</strong>Please try again in a moment.<div><button className="btn" style={{ marginTop: 12 }} onClick={retry} data-testid="button-retry">Retry</button></div></div>; }
function Empty({ title, text }: { title: string; text: string }) { return <div className="empty"><strong>{title}</strong>{text}</div>; }
function formatBits(n: number) { return new Intl.NumberFormat('en-US').format(n); }
function dateLabel(s: string) { const d = new Date(s); return Number.isNaN(d.getTime()) ? s : d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }); }

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk(); const qc = useQueryClient(); const prev = useRef<string | null | undefined>(undefined);
  useEffect(() => { const unsubscribe = addListener(({ user }) => { const id = user?.id ?? null; if (prev.current !== undefined && prev.current !== id) qc.clear(); prev.current = id; }); return unsubscribe; }, [addListener, qc]);
  return null;
}
function SignInPage() { return <div className="auth-screen"><div><div style={{ textAlign: 'center', marginBottom: 22 }}><Brand /></div><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div></div>; }
function SignUpPage() { return <div className="auth-screen"><div><div style={{ textAlign: 'center', marginBottom: 22 }}><Brand /></div><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div></div>; }
function HomeRedirect() { return <><Show when="signed-in"><Redirect to="/dashboard" /></Show><Show when="signed-out"><Home /></Show></>; }
function Protected({ children }: { children: ReactNode }) { const { isLoaded, isSignedIn } = useAuth(); if (!isLoaded) return <div className="shell" style={{ minHeight: '100dvh', display: 'grid', placeItems: 'center' }}><div style={{ width: 220, display: 'grid', gap: 12 }}><div className="loader" /><div className="loader" style={{ width: '72%' }} /></div></div>; return isSignedIn ? <>{children}</> : <Redirect to="/" />; }
function SignOutButton() { const { signOut } = useClerk(); return <button className="btn btn-quiet" onClick={() => signOut({ redirectUrl: basePath || '/' })} data-testid="button-sign-out"><LogOut size={15} /> Sign out</button>; }
const appNav = [{ href: '/dashboard', label: 'Overview', icon: LayoutDashboard }, { href: '/docs', label: 'Project notes', icon: BookOpen }, { href: '/leaderboard', label: 'Leaderboard', icon: Users }];
function AppShell({ children, active }: { children: ReactNode; active: string }) {
  const [open, setOpen] = useState(false);
  return <div className="app-layout"><aside className={`sidebar ${open ? 'open' : ''}`}><Brand /><div className="side-label">Workspace</div><nav className="side-nav">{appNav.map(item => { const Icon = item.icon; return <Link key={item.href} href={item.href} className={active === item.href ? 'active' : ''} onClick={() => setOpen(false)} data-testid={`link-app-${item.label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={16} />{item.label}</Link>; })}</nav><div className="side-bottom"><div className="side-label">Account</div><Link href="/admin" className="side-nav" style={{ padding: '11px 12px', color: '#a2a4ab', display: 'flex', gap: 12, fontSize: 13 }} data-testid="link-admin"><Shield size={16} /> Administration</Link><div style={{ padding: '14px 10px 0' }}><SignOutButton /></div></div></aside><div className="main-area"><header className="appbar"><button className="btn mobile-menu" onClick={() => setOpen(!open)} aria-label="Toggle navigation" data-testid="button-menu">{open ? <X size={16} /> : <Menu size={16} />}</button><span className="crumb">BITNOIR / {active.replace('/', '').toUpperCase()}</span><Link href="/" className="text-link" style={{ fontSize: 12, color: '#92949d' }} data-testid="link-public-home">Public site <ExternalLink size={12} style={{ verticalAlign: 'middle', marginLeft: 5 }} /></Link></header><main className="main-content">{children}</main></div></div>;
}
function AccountRoute({ active = '/dashboard' }: { active?: string }) { return <Protected><AccountPage active={active} /></Protected>; }
function AccountPage({ active }: { active: string }) {
  const profileQ = useGetMyProfile();
  return profileQ.isLoading ? <AppShell active={active}><div className="content-heading"><div className="loader" style={{ width: 175, height: 24 }} /></div><div className="dash-grid"><div className="panel panel-pad"><div className="loader" style={{ width: '40%', height: 24 }} /></div><div className="panel panel-pad"><div className="loader" style={{ width: '60%', height: 24 }} /></div></div></AppShell>
    : profileQ.isError ? <ProfileSetup onCreated={() => profileQ.refetch()} /> : <Dashboard profile={profileQ.data as UserProfile} active={active} />;
}
function ProfileSetup({ onCreated }: { onCreated: () => void }) {
  const { user } = useUser(); const create = useCreateMyProfile(); const [username, setUsername] = useState(user?.username ?? ''); const [referral, setReferral] = useState(() => new URLSearchParams(window.location.search).get('ref') ?? ''); const [message, setMessage] = useState('');
  async function submit(e: FormEvent) { e.preventDefault(); setMessage(''); if (!/^[A-Za-z0-9_]{3,24}$/.test(username)) { setMessage('Username must be 3–24 letters, numbers, or underscores.'); return; } create.mutate({ data: { username, ...(referral.trim() ? { referralCode: referral.trim() } : {}) } }, { onSuccess: () => { setMessage('Profile created.'); onCreated(); }, onError: (err) => setMessage(err instanceof Error ? err.message : 'Profile could not be created. Please retry.') }); }
  return <div className="auth-screen"><div style={{ width: 'min(440px,100%)' }}><div style={{ marginBottom: 28, textAlign: 'center' }}><Brand /></div><div className="panel panel-pad"><div className="eyebrow">Account setup</div><h1 className="page-title" style={{ marginTop: 12 }}>Make it yours.</h1><p className="page-subtitle">Choose a public username to complete your Bitnoir profile.</p><form onSubmit={submit}><label className="field-label" htmlFor="username">Username</label><input id="username" className="field" minLength={3} maxLength={24} value={username} onChange={e => setUsername(e.target.value)} placeholder="Your username" data-testid="input-username" /><label className="field-label" htmlFor="referral">Referral code <span style={{ color: '#777982' }}>(optional)</span></label><input id="referral" className="field" value={referral} onChange={e => setReferral(e.target.value)} placeholder="If someone invited you" data-testid="input-referral-code" />{message && <p className={`form-message ${create.isError ? 'error' : 'success'}`} data-testid="status-profile-setup">{message}</p>}<button className="btn btn-primary" style={{ width: '100%', marginTop: 19 }} disabled={create.isPending} data-testid="button-create-profile">{create.isPending ? 'Creating profile…' : 'Complete setup'}</button></form></div></div></div>;
}
function Dashboard({ profile, active }: { profile: UserProfile; active: string }) {
  const ledgerQ = useGetMyBitsLedger({ limit: 10, offset: 0 });
  const walletsQ = useGetMyWallets();
  return <AppShell active={active}><div className="content-heading"><div className="eyebrow">Your account</div><h1 className="page-title" style={{ marginTop: 12 }}>Good to see you, {profile.username}.</h1><p className="page-subtitle">Your Bitnoir account, current participation, and verified connections.</p></div>
    {profile.role === 'super_admin' && <div className="notice" style={{ marginBottom: 18 }} data-testid="notice-first-admin-risk"><b>Private launch setup notice · Super Admin</b><br />The first account to register is automatically assigned Super Admin. This is a material risk before public launch. Confirm this is the intended administrator, keep registration controlled during setup, and review the account list before opening access.</div>}
    <div className="dash-grid"><section className="panel panel-pad"><div className="metric"><div className="metric-icon"><Sparkles size={19} /></div><div><div className="metric-label">Internal Bits balance</div><div className="metric-value" data-testid="text-bits-balance">{formatBits(profile.bitsBalance)}</div></div></div><p style={{ color: '#777982', fontSize: 10, lineHeight: 1.6, margin: '15px 0 0' }}>Bits are internal points and have no promised monetary value.</p></section>
      <section className="panel panel-pad"><div className="panel-heading"><h2>Your profile</h2><span className="chip">{profile.role === 'super_admin' ? 'Super Admin' : 'Member'}</span></div><div className="wallet-row"><span style={{ color: '#858790', fontSize: 11 }}>Username</span><span data-testid="text-username">{profile.username}</span></div><div className="wallet-row"><span style={{ color: '#858790', fontSize: 11 }}>Joined</span><span>{dateLabel(profile.createdAt)}</span></div><div className="wallet-row"><span style={{ color: '#858790', fontSize: 11 }}>Referred by</span><span>{profile.referredByUsername || '—'}</span></div></section>
      <section className="panel panel-pad"><div className="panel-heading"><h2>Invite link</h2><span className="meta">REFERRAL</span></div><Referral profile={profile} /></section><Transfer profile={profile} />
      <section className="panel panel-pad wide"><div className="panel-heading"><h2>Bits activity</h2><span className="meta">LATEST ENTRIES</span></div>{ledgerQ.isLoading ? <SkeletonRows /> : ledgerQ.isError ? <QueryError retry={() => ledgerQ.refetch()} /> : !(ledgerQ.data as BitsLedgerEntry[] | undefined)?.length ? <Empty title="Your ledger is quiet" text="Account activity will be recorded here when it occurs." /> : <LedgerRows entries={ledgerQ.data as BitsLedgerEntry[]} />}</section>
      <WalletPanel query={walletsQ} />
      <section className="panel panel-pad coming"><div className="coming-mark">Unavailable</div><h2 style={{ font: '500 21px var(--app-font-serif)', margin: '10px 0 7px' }}>AI crypto intelligence</h2><p style={{ color: '#8f9199', fontSize: 12, lineHeight: 1.7, maxWidth: 360 }}>AI-assisted research is planned, but is not currently available. No analysis or recommendations are being generated.</p></section>
      <section className="panel panel-pad coming"><div className="coming-mark">Unavailable</div><h2 style={{ font: '500 21px var(--app-font-serif)', margin: '10px 0 7px' }}>On-chain services</h2><p style={{ color: '#8f9199', fontSize: 12, lineHeight: 1.7, maxWidth: 360 }}>Farming, token payments, deposits, withdrawals, and swaps are not available in this release.</p></section>
    </div></AppShell>;
}
function Referral({ profile }: { profile: UserProfile }) {
  const [copied, setCopied] = useState(false); const url = `${window.location.origin}${basePath}/sign-up?ref=${encodeURIComponent(profile.referralCode)}`;
  async function copy() { try { await navigator.clipboard.writeText(url); setCopied(true); window.setTimeout(() => setCopied(false), 1800); } catch { setCopied(false); } }
  return <><label className="field-label" htmlFor="ref-link">Share your referral link</label><div className="copyline"><input id="ref-link" readOnly value={url} className="field" data-testid="input-referral-link" /><button className="btn" onClick={copy} aria-label="Copy referral link" data-testid="button-copy-referral">{copied ? <Check size={15} /> : <Copy size={15} />}</button></div><div className="form-message" data-testid="status-referral-copy">{copied ? 'Link copied to clipboard.' : `Code: ${profile.referralCode}`}</div></>;
}
function Transfer({ profile }: { profile: UserProfile }) {
  const mutation = useTransferBits(); const qc = useQueryClient(); const [to, setTo] = useState(''); const [amount, setAmount] = useState(''); const [msg, setMsg] = useState('');
  function submit(e: FormEvent) { e.preventDefault(); setMsg(''); const n = Number(amount); if (!/^[A-Za-z0-9_]{3,24}$/.test(to) || !Number.isInteger(n) || n < 1) { setMsg('Enter a valid username and a whole-number Bits amount.'); return; } if (to.toLowerCase() === profile.username.toLowerCase()) { setMsg('You cannot transfer Bits to your own account.'); return; } mutation.mutate({ data: { recipientUsername: to, amount: n, idempotencyKey: crypto.randomUUID() } }, { onSuccess: async () => { setMsg('Transfer recorded successfully.'); setTo(''); setAmount(''); await Promise.all([qc.invalidateQueries({ queryKey: getGetMyProfileQueryKey() }), qc.invalidateQueries({ queryKey: getGetMyBitsLedgerQueryKey({ limit: 10, offset: 0 }) })]); }, onError: err => setMsg(err instanceof Error ? err.message : 'Transfer could not be completed.') }); }
  return <section className="panel panel-pad"><div className="panel-heading"><h2>Send Bits</h2><ArrowLeftRight size={15} color="#d9b85b" /></div><p style={{ color: '#858790', fontSize: 11, lineHeight: 1.6 }}>Internal points transfer only. Bits have no promised monetary value.</p><form onSubmit={submit}><label htmlFor="recipient" className="field-label">Recipient username</label><input id="recipient" className="field" value={to} onChange={e => setTo(e.target.value)} placeholder="username" data-testid="input-transfer-recipient" /><label htmlFor="transfer-amount" className="field-label">Amount in Bits</label><input id="transfer-amount" className="field" type="number" min="1" step="1" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0" data-testid="input-transfer-amount" />{msg && <div className={`form-message ${mutation.isError ? 'error' : 'success'}`} data-testid="status-transfer">{msg}</div>}<button className="btn btn-primary" style={{ width: '100%', marginTop: 15 }} disabled={mutation.isPending} data-testid="button-send-bits">{mutation.isPending ? 'Sending…' : 'Send Bits'}</button></form></section>;
}
function LedgerRows({ entries }: { entries: BitsLedgerEntry[] }) {
  return <div style={{ overflowX: 'auto' }}><table className="table"><thead><tr><th>Activity</th><th>Description</th><th>Date</th><th style={{ textAlign: 'right' }}>Balance after</th></tr></thead><tbody>{entries.map(e => <tr key={e.id} data-testid={`row-ledger-${e.id}`}><td><span className="userline"><span className="metric-icon" style={{ width: 26, height: 26 }}>{e.amount >= 0 ? <ArrowDownLeft size={13} /> : <ArrowUpRight size={13} />}</span><span>{e.kind.replaceAll('_', ' ')}</span></span></td><td>{e.description}</td><td>{dateLabel(e.createdAt)}</td><td className="mono" style={{ textAlign: 'right' }}>{formatBits(e.balanceAfter)}</td></tr>)}</tbody></table></div>;
}
function WalletPanel({ query }: { query: ReturnType<typeof useGetMyWallets> }) {
  const nonceQ = useGetWalletNonce({ query: { enabled: false, queryKey: ['/api/wallets/nonce'] } });
  const verify = useVerifyWallet(); const qc = useQueryClient(); const [state, setState] = useState('');
  async function associate() {
    setState('');
    const ethereum = (window as Window & { ethereum?: { request(args: { method: string; params?: unknown[] }): Promise<unknown> } }).ethereum;
    if (!ethereum) { setState('No compatible EVM wallet was detected in this browser.'); return; }
    try {
      const accounts = await ethereum.request({ method: 'eth_requestAccounts' }) as string[];
      const address = accounts?.[0]; if (!address) throw new Error('Wallet did not provide an account.');
      const nonceResult = await nonceQ.refetch(); const challenge = nonceResult.data;
      if (!challenge) throw new Error('Could not get a wallet verification challenge.');
      const signature = await ethereum.request({ method: 'personal_sign', params: [challenge.message, address] }) as string;
      const chainRaw = await ethereum.request({ method: 'eth_chainId' }) as string;
      verify.mutate({ data: { address, nonce: challenge.nonce, signature, chainId: Number.parseInt(chainRaw, 16) } }, { onSuccess: async () => { setState('Wallet verified and associated.'); await qc.invalidateQueries({ queryKey: getGetMyWalletsQueryKey() }); }, onError: err => setState(err instanceof Error ? err.message : 'Wallet verification failed.') });
    } catch (err) { setState(err instanceof Error ? err.message : 'Wallet verification was cancelled or failed.'); }
  }
  return <section className="panel panel-pad"><div className="panel-heading"><h2>Verified wallets</h2><span className="meta">OWNERSHIP PROOF</span></div>{query.isLoading ? <SkeletonRows /> : query.isError ? <QueryError retry={() => query.refetch()} /> : (query.data as WalletAssociation[] | undefined)?.length ? (query.data as WalletAssociation[]).map(w => <div className="wallet-row" key={`${w.address}-${w.chainId}`} data-testid={`row-wallet-${w.address}`}><div><div className="wallet-address">{w.address.slice(0, 8)}…{w.address.slice(-7)}</div><div style={{ color: '#787b83', fontSize: 10, marginTop: 5 }}>Chain {w.chainId} · verified {dateLabel(w.verifiedAt)}</div></div><span className="chip good">Verified</span></div>) : <Empty title="No wallet associations" text="Prove ownership to associate an EVM wallet with your account." />}<button onClick={associate} className="btn" style={{ width: '100%', marginTop: 14 }} disabled={verify.isPending} data-testid="button-verify-wallet"><Wallet size={15} />{verify.isPending ? 'Verifying…' : 'Verify wallet ownership'}</button>{state && <p className={`form-message ${verify.isError ? 'error' : 'success'}`} data-testid="status-wallet">{state}</p>}<p style={{ color: '#686b74', fontSize: 10, lineHeight: 1.6, margin: '10px 0 0' }}>This signs a verification challenge only. No transaction or token transfer is initiated.</p></section>;
}

function AdminPage() {
  const { isLoaded, isSignedIn } = useAuth(); const profileQ = useGetMyProfile({ query: { enabled: isLoaded && isSignedIn, queryKey: getGetMyProfileQueryKey() } });
  if (!isLoaded) return <div className="shell" style={{ minHeight: '100dvh', display: 'grid', placeItems: 'center' }}><div className="loader" style={{ width: 220 }} /></div>;
  if (!isSignedIn) return <Redirect to="/" />;
  if (profileQ.isLoading) return <div className="shell" style={{ minHeight: '100dvh' }} />;
  if (profileQ.isError || (profileQ.data as UserProfile).role !== 'super_admin') return <AppShell active="/admin"><div className="panel panel-pad" style={{ maxWidth: 620 }}><div className="metric-icon"><Shield size={19} /></div><h1 className="page-title" style={{ marginTop: 17 }}>Restricted area</h1><p className="page-subtitle">This account is not authorized for administration. Access is enforced by the backend.</p><Link href="/dashboard" className="btn" style={{ marginTop: 20 }} data-testid="link-return-dashboard">Return to account</Link></div></AppShell>;
  return <AdminContent />;
}
function AdminContent() {
  const params = { limit: 50, offset: 0 };
  const [ledgerOffset, setLedgerOffset] = useState(0);
  const ledgerParams = { limit: 50, offset: ledgerOffset };
  const usersQ = useGetAdminUsers(params); const auditQ = useGetAdminAuditLog(params); const ledgerQ = useGetAdminBitsLedger(ledgerParams);
  const users = usersQ.data as AdminUser[] | undefined; const events = auditQ.data as AuditEvent[] | undefined; const ledger = ledgerQ.data as AdminLedgerEntry[] | undefined;
  return <AppShell active="/admin"><div className="content-heading"><div className="eyebrow">Private administration</div><h1 className="page-title" style={{ marginTop: 12 }}>Account oversight</h1><p className="page-subtitle">Backend-authorized Super Admin tools. Account actions are recorded in the audit history.</p></div>
    <div className="dash-grid"><section className="panel panel-pad wide"><div className="panel-heading"><h2>Bits ledger</h2><span className="meta">LATEST ENTRIES</span></div>{ledgerQ.isLoading ? <SkeletonRows /> : ledgerQ.isError ? <QueryError retry={() => ledgerQ.refetch()} /> : !ledger?.length ? <Empty title="No ledger entries" text="Bits activity will appear here when recorded." /> : <><div style={{ overflowX: 'auto' }}><table className="table"><thead><tr><th>Account</th><th>Kind</th><th>Description</th><th style={{ textAlign: 'right' }}>Amount</th><th style={{ textAlign: 'right' }}>Balance after</th><th>Date</th></tr></thead><tbody>{ledger.map(e => <tr key={e.id} data-testid={`row-admin-ledger-${e.id}`}><td>{e.username}</td><td>{e.kind.replaceAll('_', ' ')}</td><td>{e.description}</td><td className="mono" style={{ textAlign: 'right' }}>{e.amount > 0 ? '+' : ''}{formatBits(e.amount)}</td><td className="mono" style={{ textAlign: 'right' }}>{formatBits(e.balanceAfter)}</td><td>{dateLabel(e.createdAt)}</td></tr>)}</tbody></table></div><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 15 }}><span className="meta" style={{ color: '#777982', font: '10px var(--app-font-mono)' }}>Entries {ledgerOffset + 1}–{ledgerOffset + ledger.length}</span><div style={{ display: 'flex', gap: 8 }}><button className="btn" disabled={ledgerOffset === 0} onClick={() => setLedgerOffset(Math.max(0, ledgerOffset - 50))} data-testid="button-ledger-previous">Previous</button><button className="btn" disabled={ledger.length < 50} onClick={() => setLedgerOffset(ledgerOffset + 50)} data-testid="button-ledger-next">Next</button></div></div></>}</section>
    <section className="panel panel-pad wide"><div className="panel-heading"><h2>Accounts</h2><span className="meta">USERNAME · ROLE · BITS · STATUS</span></div>{usersQ.isLoading ? <SkeletonRows /> : usersQ.isError ? <QueryError retry={() => usersQ.refetch()} /> : !users?.length ? <Empty title="No accounts returned" text="The account directory is currently empty." /> : <div style={{ overflowX: 'auto' }}><table className="table"><thead><tr><th>Account</th><th>Role</th><th style={{ textAlign: 'right' }}>Bits</th><th>Status</th><th>Joined</th></tr></thead><tbody>{users.map(u => <tr key={u.id} data-testid={`row-admin-user-${u.id}`}><td>{u.username}</td><td>{u.role === 'super_admin' ? 'Super Admin' : 'Member'}</td><td className="mono" style={{ textAlign: 'right' }}>{formatBits(u.bitsBalance)}</td><td><span className={`chip ${u.suspended ? 'warn' : 'good'}`}>{u.suspended ? 'Suspended' : 'Active'}</span></td><td>{dateLabel(u.createdAt)}</td></tr>)}</tbody></table></div>}</section>
    <section className="panel panel-pad wide"><div className="panel-heading"><h2>Audit history</h2><span className="meta">LATEST EVENTS</span></div>{auditQ.isLoading ? <SkeletonRows /> : auditQ.isError ? <QueryError retry={() => auditQ.refetch()} /> : !events?.length ? <Empty title="No recorded actions yet" text="Administrative actions will be listed here." /> : <div style={{ overflowX: 'auto' }}><table className="table"><thead><tr><th>Actor</th><th>Action</th><th>Target</th><th>Date</th></tr></thead><tbody>{events.map((e, i) => <tr key={e.id} data-testid={`row-audit-${e.id || i}`}><td>{e.actorUsername}</td><td>{e.action}</td><td>{e.targetUsername || '—'}</td><td>{dateLabel(e.createdAt)}</td></tr>)}</tbody></table></div>}</section>
    </div></AppShell>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) { const [location] = useLocation(); return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>; }
function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={HomeRedirect} />
    <Route path="/sign-in/*?" component={SignInPage} /><Route path="/sign-up/*?" component={SignUpPage} />
    <Route path="/docs" component={Docs} /><Route path="/leaderboard" component={Leaderboard} />
    <Route path="/dashboard" component={() => <AccountRoute />} /><Route path="/admin" component={AdminPage} />
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}
function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}
    localization={{ signIn: { start: { title: 'Welcome back', subtitle: 'Sign in to your Bitnoir account' } }, signUp: { start: { title: 'Join Bitnoir', subtitle: 'Create your account and get started' } } }}
    routerPush={to => setLocation(stripBase(to))} routerReplace={to => setLocation(stripBase(to), { replace: true })}>
    <QueryClientProvider client={queryClient}><ClerkQueryClientCacheInvalidator /><TooltipProvider><Router /><Toaster /></TooltipProvider></QueryClientProvider>
  </ClerkProvider>;
}
function App() { return <WouterRouter base={basePath}><ClerkProviderWithRoutes /></WouterRouter>; }
export default App;
